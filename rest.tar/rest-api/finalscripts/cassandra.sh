#!/bin/bash

apt-get update

apt-get install firefox eclipse geany -y

apt-get install xrdp icewm idesk dpkg rox-filer -y

apt-get install xterm zip unzip nautilus -y

#here script install adobereader:-

dpkg --add-architecture i386

apt-get update

apt-get install gtk2-engines-murrine:i386 libcanberra-gtk-module:i386 libatk-adaptor:i386 libgail-common:i386 -y

add-apt-repository "deb http://archive.canonical.com/ precise partner"

apt-get update

apt-get install adobereader-enu -y

#here script install php-bind and apache2:-

apt-get install apache2 -y

systemctl stop apache2.service

systemctl start apache2.service

systemctl enable apache2.service

#script create linkfiles:-

wget -O rox.png http://worldartsme.com/images/blue-ball-clipart-1.jpg

wget -O cassandra.png  https://cdn-images-1.medium.com/max/800/1*nUWE_JJ44Sg5iiT3n50dTQ.png

mv {cassandra.png,rox.png,} /usr/share/pixmaps/

cp /usr/share/icons/hicolor/16x16/apps/firefox.png /usr/share/pixmaps/

#here the script tells shell to install java8:-

apt-get update

apt install openjdk-8-jre-headless -y

export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64

export PATH=$JAVA_HOME/bin:$PATH

#hear script perform directory struchure:-

mkdir -p /home/ubuntu/backup/{handson,slides,outline,backup}

touch /home/ubuntu/backup/instructions

mkdir -p /home/ubuntu/{.icewm,.idesktop}

cp /usr/share/idesk/dot.ideskrc /home/ubuntu/.ideskrc

touch /home/ubuntu/.icewm/.ideskrc

echo "idesk >> /tmp/idesklog &" > /home/ubuntu/.icewm/startup

chmod +x /home/ubuntu/.icewm/startup

echo "FocusMode=0" > /home/ubuntu/.icewm/focus_mode

#here script wll perform loop:-

echo "table Icon
  Caption: Home
  ToolTip.Caption: MY Home
  Icon: /home/ubuntu/.idesktop/home.png
  Command[0]: nautilus /home/ubuntu
  Command[1]: nautilus /home/ubuntu/backup
end " >> /home/ubuntu/.ideskrc

echo "table Icon
  Caption: Courseware
  ToolTip.caption: /home/ubuntu/Guide
  Icon: /usr/share/pixmaps/cassandra.png
  Width: 100
  Height: 100
  X: 0
  Y: 0
  Command[0]: nautilus /home/ubuntu/backup
  Command[1]: nautilus /home/ubuntu/backup/handson
end " > /home/ubuntu/.idesktop/home.lnk

var=(firefox.lnk geany.lnk eclipse.lnk rox.lnk Adobe.lnk)
var1=(firefox geany eclipse rox acroread)
var2=(firefox.png geany.xpm eclipse.png rox.png AdobeReader9.png)
var3=(Firefox Geany Eclipse Rox-filer Adobereader)

for i in 0 1 2 3 4 
do 
cp /usr/share/idesk/default.lnk /home/ubuntu/.idesktop/${var[$i]}
find / -name "${var[$i]}" -exec sed -i "s/Idesk/${var3[$i]}/g;s/48/32/g;s/30/0/g;s/idesk/pixmaps/g;s/folder_home.xpm/${var2[$i]}/g;s/xmessage/${var1[$i]} #/g" '{}' \;

done

#here the script perform cassandra install:-

echo "deb http://www.apache.org/dist/cassandra/debian 311x main" | sudo tee -a /etc/apt/sources.list.d/cassandra.sources.list
 
curl https://www.apache.org/dist/cassandra/KEYS | sudo apt-key add -

apt-key adv --keyserver pool.sks-keyservers.net --recv-key A278B781FE4B2BDA

apt-get update

apt-get install cassandra -y

systemctl start cassandra.service

systemctl stop cassandra.service

systemctl enable cassandra.service 

chown -R ubuntu:ubuntu /home/ubuntu

echo -e "ub4ntu4\nub4ntu4" | (passwd ubuntu)

exit 0

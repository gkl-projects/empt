#!/bin/bash

apt-get update

apt-get install firefox eclipse geany -y

apt-get install xrdp icewm idesk dpkg rox-filer -y

apt-get install xterm zip unzip nautilus -y

#here script install adobereader:-

dpkg --add-architecture i386

apt-get update

apt-get install gtk2-engines-murrine:i386 libcanberra-gtk-module:i386 libatk-adaptor:i386 libgail-common:i386 -y

add-apt-repository "deb http://archive.canonical.com/ precise partner"

apt-get update

apt-get install adobereader-enu -y

#here script install php-bind and apache2:-

apt-get install apache2 -y

systemctl stop apache2.service

systemctl start apache2.service

systemctl enable apache2.service

#script create linkfiles:-

wget -O rox.png http://worldartsme.com/images/blue-ball-clipart-1.jpg

wget -O hazilcast.png https://hazelcast.com/wp-content/uploads/2014/03/HazelcastLogo-Blue_Dark_Vertical_500w1.png

mv {hazilcast.png,rox.png,} /usr/share/pixmaps/

cp /usr/share/icons/hicolor/16x16/apps/firefox.png /usr/share/pixmaps/

#hear script perform directory struchure:-

mkdir -p /home/ubuntu/backup/{handson,slides,outline,backup}

touch /home/ubuntu/backup/instructions

mkdir -p /home/ubuntu/{.icewm,.idesktop}

cp /usr/share/idesk/dot.ideskrc /home/ubuntu/.ideskrc

touch /home/ubuntu/.icewm/.ideskrc

echo "idesk >> /tmp/idesklog &" > /home/ubuntu/.icewm/startup

chmod +x /home/ubuntu/.icewm/startup

echo "FocusMode=0" > /home/ubuntu/.icewm/focus_mode

chown -R ubuntu:ubuntu /home/ubuntu

#here script wll perform loop:-

echo "table Icon
  Caption: Home
  ToolTip.Caption: MY Home
  Icon: /home/ubuntu/.idesktop/home.png
  Command[0]: nautilus /home/ubuntu
  Command[1]: nautilus /home/ubuntu/backup
end " >> /home/ubuntu/.ideskrc

echo "table Icon
  Caption: Courseware
  ToolTip.caption: /home/ubuntu/Guide
  Icon: /usr/share/pixmaps/hazilcast.png
  Width: 100
  Height: 100
  X: 0
  Y: 0
  Command[0]: nautilus /home/ubuntu/backup
  Command[1]: nautilus /home/ubuntu/backup/handson
end " > /home/ubuntu/.idesktop/home.lnk

var=(firefox.lnk geany.lnk eclipse.lnk rox.lnk Adobe.lnk)
var1=(firefox geany eclipse rox acroread)
var2=(firefox.png geany.xpm eclipse.png rox.png AdobeReader9.png)
var3=(Firefox Geany Eclipse Rox-filer Adobereader)

for i in 0 1 2 3 4 
do 
cp /usr/share/idesk/default.lnk /home/ubuntu/.idesktop/${var[$i]}
find / -name "${var[$i]}" -exec sed -i "s/Idesk/${var3[$i]}/g;s/48/32/g;s/30/0/g;s/idesk/pixmaps/g;s/folder_home.xpm/${var2[$i]}/g;s/xmessage/${var1[$i]} #/g" '{}' \;

done

#here the script tells shell to install java8:-

apt-get update

apt install openjdk-8-jre-headless -y

export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64

export PATH=$JAVA_HOME/bin:$PATH

#here the script tells shell to install ant:-

apt-get install ant -y

wget http://www-eu.apache.org/dist//ant/binaries/apache-ant-1.9.13-bin.tar.gz

tar -xf apache-ant-1.9.13-bin.tar.gz  -C /usr/local

ln -s /usr/local/apache-ant-1.9.13/ /usr/local/ant

export ANT_HOME=/usr/local/ant

export PATH=$ANT_HOME/bin:$PATH

#here script tells shell to install maven and setup path:-

apt-get install maven -y

wget -P /opt http://www-eu.apache.org/dist/maven/maven-3/3.3.9/binaries/apache-maven-3.3.9-bin.tar.gz

tar -xzf /opt/apache-maven-3.3.9-bin.tar.gz

mv apache-maven-3.3.9 maven 

mv maven /opt	

export M2_HOME=/opt/maven

export PATH=$M2_HOME/bin:$PATH

#here the script tells shell to install hazelcast:-

wget -O hazelcast.tar.gz "https://download.hazelcast.com/download.jsp?version=hazelcast-3.6.6&type=tar&p="

tar -xzf hazelcast.tar.gz

mv hazelcast-3.6.6 hazelcast

mv hazelcast /home/ubuntu

chown -R ubuntu:ubuntu /home/ubuntu

echo -e "ub4ntu4\nub4ntu4" | (passwd ubuntu)

exit 0

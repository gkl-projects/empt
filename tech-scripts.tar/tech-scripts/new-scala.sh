#!/bin/bash

apt-get update

apt-get install firefox eclipse geany -y

apt-get install xrdp icewm idesk dpkg rox-filer -y

apt-get install xterm zip unzip nautilus -y

#here script install adobereader:-

dpkg --add-architecture i386

apt-get update

apt-get install gtk2-engines-murrine:i386 libcanberra-gtk-module:i386 libatk-adaptor:i386 libgail-common:i386 -y

add-apt-repository "deb http://archive.canonical.com/ precise partner"

apt-get update

apt-get install adobereader-enu -y

#here script install php-bind and apache2:-

apt-get install apache2 -y

systemctl stop apache2.service

systemctl start apache2.service

systemctl enable apache2.service

#script create linkfiles:-

wget -O fox.png https://banner2.kisspng.com/20180324/zpe/kisspng-mozilla-foundation-firefox-logo-web-browser-comput-firefox-5ab6eebe5697a5.6497391415219381103547.jpg

wget -O rox.png http://worldartsme.com/images/blue-ball-clipart-1.jpg

wget -O scala.png https://pedrorijo.com/assets/img/scala-logo.png

mv {scala.png,rox.png} /usr/share/pixmaps/

ln -s /usr/share/icons/hicolor/16x16/apps/firefox.png /usr/share/pixmaps/firefox.png

#hear script perform directory struchure:-

mkdir -p /home/ubuntu/backup/{handson,slides,outline,backup}

touch /home/ubuntu/backup/instructions

mkdir -p /home/ubuntu/{.icewm,.idesktop}

cp /usr/share/idesk/dot.ideskrc /home/ubuntu/.ideskrc

touch /home/ubuntu/.icewm/.ideskrc

echo "idesk >> /tmp/idesklog &" > /home/ubuntu/.icewm/startup

chmod +x /home/ubuntu/.icewm/startup

echo "FocusMode=0" > /home/ubuntu/.icewm/focus_mode

chown -R ubuntu:ubuntu /home/ubuntu

#here script wll perform loop:-

echo "table Icon
  Caption: Home
  ToolTip.Caption: MY Home
  Icon: /home/ubuntu/.idesktop/home.png
  Command[0]: nautilus /home/ubuntu
  Command[1]: nautilus /home/ubuntu/backup
end " >> /home/ubuntu/.ideskrc

echo "table Icon
  Caption: Courseware
  ToolTip.caption: /home/ubuntu/Guide
  Icon: /usr/share/pixmaps/scala.png
  Width: 100
  Height: 100
  X: 919
  Y: 303
  Command[0]: nautilus /home/ubuntu/backup
  Command[1]: nautilus /home/ubuntu/backup/handson
end " > /home/ubuntu/.idesktop/home.lnk

var=(firefox.lnk geany.lnk eclipse.lnk rox.lnk Adobe.lnk)
var1=(firefox geany eclipse Rox-filer AdobeReader)
var2=(fox.png geany.xpm eclipse.png rox.png AdobeReader9.png)

for i in 0 1 2 3 4 
do 
cp /usr/share/idesk/default.lnk /home/ubuntu/.idesktop/${var[$i]}
find / -name "${var[$i]}" -exec sed -i "s/Idesk/${var1[$i]}/g;s/48/32/g;s/30/0/g;s/idesk/pixmaps/g;s/folder_home.xpm/${var2[$i]}/g;s/xmessage/${var1[$i]} #/g" '{}' \;

done

#here the script tells shell to install java8:-

apt-get update

apt install openjdk-8-jre-headless -y

export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64

export PATH=$JAVA_HOME/bin:$PATH

#here the script tells shell to install ant:-

apt-get install ant -y

wget http://www-eu.apache.org/dist//ant/binaries/apache-ant-1.9.13-bin.tar.gz

tar -xf apache-ant-1.9.13-bin.tar.gz  -C /usr/local

ln -s /usr/local/apache-ant-1.9.13/ /usr/local/ant

export ANT_HOME=/usr/local/ant

export PATH=$ANT_HOME/bin:$PATH

#here script tells shell to install maven and setup path:-

apt-get install maven -y

wget -P /opt http://www-eu.apache.org/dist/maven/maven-3/3.3.9/binaries/apache-maven-3.3.9-bin.tar.gz

tar -xzf /opt/apache-maven-3.3.9-bin.tar.gz

mv apache-maven-3.3.9 maven 

mv maveen /opt	

export M2_HOME=/opt/maven

export PATH=$M2_HOME/bin:$PATH

#here the script tells shell to install sala:-

wget https://downloads.lightbend.com/scala/2.12.6/scala-2.12.6.deb

apt-get install dpkg -y

dpkg -i scala-2.12.6.deb 

#here script tells shell to install sbt:-

echo "deb https://dl.bintray.com/sbt/debian /" | sudo tee -a /etc/apt/sources.list.d/sbt.list

apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 2EE0EA64E40A89B84B2DF73499E82A75642AC823

apt-get update

apt-get install sbt 

chown -R ubuntu:ubuntu /home/ubuntu

echo -e "ub4ntu4\nub4ntu4" | (passwd ubuntu)

exit 0



























